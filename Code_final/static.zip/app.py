from flask import Flask, jsonify, render_template, request ,redirect, url_for
from flask_bootstrap import Bootstrap
from dataclasses import dataclass, field
from typing import List

app = Flask(__name__)
bootstrap = Bootstrap(app)

@dataclass
class Erreur:
    typeErreur: str
    descriptionErreur: str

@dataclass
class Phrase:
    contenu: str
    fautes: List[Erreur] = field(default_factory=list)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle the form submission here
        # For example, redirect to another page or perform some action
        return redirect(url_for('index'))  # Replace 'index' with the appropriate route
    else:
        # Handle GET request (display the form)
        return render_template('index.html')

def compter_erreurs_par_type(phrases):
    # Initialisation des compteurs
    nb_erreurs_conjugaison = 0
    nb_erreurs_orthographe = 0
    nb_erreurs_accord = 0

    # Parcourir chaque phrase
    for phrase in phrases:
        # Parcourir chaque erreur dans la phrase
        for erreur in phrase.fautes:
            # Incrémenter le compteur approprié en fonction du type d'erreur
            if erreur.typeErreur == "Conjugaison":
                nb_erreurs_conjugaison += 1
            elif erreur.typeErreur == "Orthographe":
                nb_erreurs_orthographe += 1
            elif erreur.typeErreur == "Accord":
                nb_erreurs_accord += 1
    
    return nb_erreurs_conjugaison, nb_erreurs_orthographe, nb_erreurs_accord

# Utilisation de la fonction avec la liste phrases_exemple
def calculer_penalites(phrases):
    nb_total_fautes = 0
    penalite_orthographe = 0
    penalite_conjugaison = 0
    penalite_accord = 0

    for phrase in phrases:
        for erreur in phrase.fautes:
            nb_total_fautes += 1
            if erreur.typeErreur == "Orthographe":
                penalite_orthographe += 2
            elif erreur.typeErreur == "Conjugaison":
                penalite_conjugaison += 1
            elif erreur.typeErreur == "Accord":
                penalite_accord += 1

    penalite_totale = penalite_orthographe + penalite_conjugaison + penalite_accord
    return nb_total_fautes, penalite_orthographe, penalite_conjugaison, penalite_accord, penalite_totale

@app.route('/corrector', methods=['POST'])
def correction():
    texte = request.form.get('texte')  # Récupérez le texte
    # Simulation
    phrases_exemple = [
        Phrase("Ceci est une phrase sans faute.", []),
        Phrase("Il mange une pomme.", []),
        Phrase("Le chien cour vite dans le jardin.", [Erreur("Orthographe", "cour doit être remplacé par court")]),
        Phrase("Elle a acheter un nouveau livre.", [Erreur("Conjugaison", "acheter doit être remplacé par acheté")]),
        Phrase("Les livres est sur la table.", [Erreur("Accord", "est doit être remplacé par sont")]),
        Phrase("Les livres est sur la table.", [Erreur("Accord", "est doit être remplacé par sont")]),
        Phrase("Ceci est une phrase sans faute.", []),
        Phrase("Il mange une pomme.", []),
        Phrase("Le chien cour vite dans le jardin.", [Erreur("Orthographe", "cour doit être remplacé par court")]),
        Phrase("Elle a acheter un nouveau livre.", [Erreur("Conjugaison", "acheter doit être remplacé par acheté")]),
        Phrase("Les livres est sur la table.", [Erreur("Accord", "est doit être remplacé par sont")]),
        Phrase("Les livres est sur la table.", [Erreur("Accord", "est doit être remplacé par sont")])
    ]
    phrases_exemple.append(
    Phrase("Ce livre et très interessant.", [
        Erreur("Orthographe", "et doit être remplacé par est"),
        Erreur("Orthographe", "interessant doit être remplacé par intéressant"),
    ])
)
    # Appliquez la correction ici sur le texte soumis
    nb_erreurs_conjugaison, nb_erreurs_orthographe, nb_erreurs_accord = compter_erreurs_par_type(phrases_exemple)
    ratio_orthographe = round(nb_erreurs_orthographe / (nb_erreurs_conjugaison + nb_erreurs_orthographe + nb_erreurs_accord) * 100, 2)
    ratio_conjugaison = round(nb_erreurs_conjugaison / (nb_erreurs_conjugaison + nb_erreurs_orthographe + nb_erreurs_accord) * 100, 2)
    ratio_accord = round(nb_erreurs_accord / (nb_erreurs_conjugaison + nb_erreurs_orthographe + nb_erreurs_accord)* 100, 2)
    print(ratio_orthographe)

    nb_total_fautes, penalite_orthographe, penalite_conjugaison, penalite_accord, penalite_totale = calculer_penalites(phrases_exemple)
    print(penalite_totale)
    return render_template('correction.html', texte=texte, phrases=phrases_exemple, nb_erreurs_conjugaison=nb_erreurs_conjugaison, nb_erreurs_orthographe=nb_erreurs_orthographe, nb_erreurs_accord=nb_erreurs_accord, ratio_orthographe=ratio_orthographe, ratio_conjugaison=ratio_conjugaison, ratio_accord=ratio_accord, nb_total_fautes=nb_total_fautes, penalite_orthographe=penalite_orthographe, penalite_conjugaison=penalite_conjugaison, penalite_accord=penalite_accord, penalite_totale=penalite_totale)

@app.route('/ignore_fault', methods=['POST'])
def ignore_fault():
    # Extract information from the request
    # Update error counts and penalties
    # Recalculate progress bars or relevant data
    # Return updated data (possibly as JSON)
    return jsonify(updated_data)

if __name__ == '__main__':
    app.run(debug=True)



