/* script.js */
function afficherPopup(event) {
    var popup = document.getElementById('errorPopup');
    var popupText = document.getElementById('errorContent');

    // Assume event.target is the clicked error span.
    var descriptionsErreur = event.target.dataset.description.split("|");
    var typesErreur = event.target.dataset.typeerreur.split("|");

    popupText.innerHTML = ""; // Clear previous content
    descriptionsErreur.forEach((description, index) => {
        var errorText = document.createElement("p");
        errorText.textContent = "Erreur " + typesErreur[index] + " : " + description;
        popupText.appendChild(errorText);

        var ignoreButton = document.createElement("button");
        ignoreButton.textContent = "Ignorer faute";

        ignoreButton.onclick = function() { ignorerFaute(typesErreur[index], event.target); };
        popupText.appendChild(ignoreButton);
    });
    popup.style.left = (event.clientX + 10) + 'px'; // Positionner la popup près de la souris
    popup.style.top = (event.clientY + 10) + 'px';
    popup.style.display = 'block';
    // Position popup based on event details or use fixed positioning.
}

function ignorerFaute(typeErreur, targetElement) {
    // Code to handle error ignoring logic, send request to backend, and update UI accordingly.
    console.log("Ignoring fault of type: ", typeErreur);
    // Hide the popup
    document.getElementById('errorPopup').style.display = 'none';
    // Optionally, remove the error highlight from the target element
    targetElement.classList.remove('error');
    // You would need to send a request to the server to update the error count and then refresh the progress bars.
}


// Ajouter des gestionnaires pour fermer le popup en cliquant à l'extérieur
window.onclick = function (event) {
    var popup = document.getElementById('errorPopup');
    if (event.target == popup) {
        fermerPopup();
    }
};


function fermerPopup() {
    var popup = document.getElementById('errorPopup');
    popup.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    var editableTextarea = document.getElementById('editable-textarea');
  
    editableTextarea.addEventListener('focus', function() {
      if (this.textContent === 'Entrez votre texte à corriger ici') {
        this.textContent = ''; // Vide le contenu
        this.style.color = 'black'; // Change la couleur du texte en noir lorsque l'utilisateur commence à taper
      }
    });
  
    editableTextarea.addEventListener('blur', function() {
      if (this.textContent.trim() === '') {
        this.textContent = 'Entrez votre texte à corriger ici';
        this.style.color = 'grey'; // Revient à la couleur grise si l'utilisateur efface son entrée
      }
    });
  });

  

  
  
  

